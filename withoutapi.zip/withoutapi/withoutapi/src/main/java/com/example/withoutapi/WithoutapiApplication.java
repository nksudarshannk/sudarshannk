package com.example.withoutapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WithoutapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(WithoutapiApplication.class, args);
	}

}
