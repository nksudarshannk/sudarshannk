package com.example.Restcontroller.postman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestcontrollerPostmanApplicationTests {

	@Test
	void contextLoads() {
	}

}
