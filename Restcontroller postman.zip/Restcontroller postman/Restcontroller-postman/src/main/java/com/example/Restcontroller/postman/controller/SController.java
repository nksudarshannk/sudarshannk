package com.example.Restcontroller.postman.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.example.Restcontroller.postman.Repository.Srepo;
import com.example.Restcontroller.postman.model.Smodel;

@RestController
public class SController {
@Autowired
Srepo srepo;

@PostMapping("/addstu")
public String addstu(@RequestBody Smodel smodel) {
	srepo.save(smodel);
	return"record inserted"+smodel.getId();
}
@GetMapping("/display")
public List<Smodel>display(){
	return srepo.findAll();
}
@GetMapping("/search/{id}")
public Optional<Smodel>search(@PathVariable int id){
	return srepo.findById(id);
}
@DeleteMapping("delete/{id}")
public String delete(@PathVariable int id) {
	srepo.deleteById(id);
	return "delete"+id;
}
@PutMapping("update/{id}")
public String update(@RequestBody Smodel smodel) {
	Smodel u=srepo.findById(smodel.getId()).get();
	u.setId(smodel.getId());
	u.setName(smodel.getName());
	srepo.save(u);
	return "record updated"+smodel.getId();
}
}
