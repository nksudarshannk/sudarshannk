package com.example.Restcontroller.postman.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.Restcontroller.postman.model.Smodel;

public interface Srepo extends MongoRepository<Smodel, Integer> {

}
